jQuery.sap.declare("sap.openSAP.smarttable.Component");

sap.ui.core.UIComponent.extend("sap.openSAP.smarttable.Component", {

	metadata: {
		manifest: "json",

		dependencies: {
			libs: [
				"sap.m", "sap.ui.comp"
			]
		}
	}
});
