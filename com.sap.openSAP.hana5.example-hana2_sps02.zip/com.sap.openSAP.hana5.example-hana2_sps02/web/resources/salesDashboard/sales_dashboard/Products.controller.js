sap.ui.controller("sales_dashboard.Products", {
	
});


